//bootstrap
require('./bootstrap');

//component
require('./component/PeminjamanSiswa')

require('./component/DetailSiswa')
