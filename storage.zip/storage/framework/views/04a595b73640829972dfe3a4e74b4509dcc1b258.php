
<?php $__env->startSection('content_admin'); ?>

<div class="pagetitle">
    <h1>Pengembalian</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#">Detail Pengembalian</a></li>
        
      </ol>
    </nav>
  </div><!-- End Page Title -->
  <section class="section">
      <div class="col-lg-12">
    <div class="row">

      <div class="col-lg-6">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Data Murid</h5>            
            <div>
              <div class="row mb-3">
                <label for="inputEmail3" class="col-sm-4 col-form-label">Nama:</label>
                <div class="col-sm-8">                
                  <b><?php echo e($pengembalian_buku['murid']['nama']); ?></b>
                </div>
              </div>
              <div class="row mb-3">
                <label for="inputEmail3" class="col-sm-4 col-form-label">No Telepon:</label>
                <div class="col-sm-8">
                    <b><?php echo e($pengembalian_buku['murid']['no_telepon']); ?></b>
                </div>
              </div>
              <div class="row mb-3">
                <label for="inputPassword3" class="col-sm-4 col-form-label">Alamat:</label>
                <div class="col-sm-8">
                    <b><?php echo e($pengembalian_buku['murid']['alamat']); ?></b>
                </div>
              </div> 
              <div class="row mb-3">
                <label for="inputPassword3" class="col-sm-4 col-form-label">Tanggal Lahir:</label>
                <div class="col-sm-8">
                    <b><?php echo e($pengembalian_buku['murid']['tanggal_lahir']); ?></b>
                </div>
              </div> 
              <div class="row mb-3">
                <label for="inputPassword3" class="col-sm-4 col-form-label">Jenis Kelamin:</label>
                <div class="col-sm-8">
                    <b><?php echo e($pengembalian_buku['murid']['jenis_kelamin']); ?></b>
                </div>
              </div>                                         
            </div>

          </div>
        </div>    
      </div>

      <div class="col-lg-6">

        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Data Buku</h5>

            <div>
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-4 col-form-label">Judul:</label>
                  <div class="col-sm-8">                
                    <b><?php echo e($pengembalian_buku['buku']['judul']); ?></b>
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-4 col-form-label">Pengarang:</label>
                  <div class="col-sm-8">
                      <b><?php echo e($pengembalian_buku['buku']['pengarang']); ?></b>
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputPassword3" class="col-sm-4 col-form-label">Penerbit:</label>
                  <div class="col-sm-8">
                      <b><?php echo e($pengembalian_buku['buku']['penerbit']); ?></b>
                  </div>
                </div> 
                <div class="row mb-3">
                  <label for="inputPassword3" class="col-sm-4 col-form-label">Isbn:</label>
                  <div class="col-sm-8">
                      <b><?php echo e($pengembalian_buku['buku']['isbn']); ?></b>
                  </div>
                </div> 
                <div class="row mb-3">
                  <label for="inputPassword3" class="col-sm-4 col-form-label">Tahun:</label>
                  <div class="col-sm-8">
                      <b><?php echo e($pengembalian_buku['buku']['tahun']); ?></b>
                  </div>
                </div> 
                <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-4 col-form-label">Sampul Buku:</label>
                    <div class="col-sm-8">
                        <b><img src="<?php echo e(asset('storage/'.$pengembalian_buku['buku']['sampul_buku'] )); ?>" class="w-100" alt="sampul buku" alt=""></b>
                    </div>
                  </div>                                         
              </div>

          </div>
        </div>



      </div>
    </div>      
    </div>

      <div class="col-lg-12">
        


      <div class="col-lg-12">
        <div class="row">
    
          <div class="col-lg-12">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title">Data Pinjam Buku</h5>            
                <div>
                  <div class="row mb-3">
                    <label for="inputEmail3" class="col-sm-4 col-form-label">Jumlah Pinjam:</label>
                    <div class="col-sm-8">                
                      <b><?php echo e($pengembalian_buku['jumlah_pinjam']); ?></b>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <label for="inputEmail3" class="col-sm-4 col-form-label">Tanggal Pinjam:</label>
                    <div class="col-sm-8">
                        <b><?php echo e($pengembalian_buku['tanggal_pinjam']); ?></b>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-4 col-form-label">Batas Waktu Pengembalian:</label>
                    <div class="col-sm-8">
                        <b><?php echo e($pengembalian_buku['tanggal_di_kembalikan']); ?></b>
                    </div>
                  </div> 
                  
                </div>
            

              </div>
            </div>
          </div>
      </div>



      <div class="col-lg-12">
        <div class="row">
    
          <div class="col-lg-12">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title">Detail Denda</h5>            
                <div>
                  <?php
                    use Carbon\Carbon;
                  ?>
                   <?php
                   $denda_per_hari = 1000;                  
                   $carbon_tanggal_hari_ini = \Carbon\Carbon::now()->setTimezone('Asia/Jakarta')->format('Y-m-d');
   
   
                   $tanggal_kembali = Carbon::parse($pengembalian_buku['tanggal_di_kembalikan']); 
                   $tanggal_hari_ini =  Carbon::parse($carbon_tanggal_hari_ini);
   
                   if ($tanggal_kembali < $tanggal_hari_ini) {
                     $selisih_hari = $tanggal_hari_ini->diffInDays($tanggal_kembali);
                     $denda = $selisih_hari * $denda_per_hari;                      
                   } else {
                     $denda = 0; 
                   }
               ?>
   
                  <div class="row mb-3">
                    <label for="inputEmail3" class="col-sm-4 col-form-label">Terlambat:</label>
                    <div class="col-sm-8">                
                      <b><?php echo e($selisih_hari ?? 0); ?> Hari</b>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <label for="inputEmail3" class="col-sm-4 col-form-label">Tanggal Pinjam:</label>
                    <div class="col-sm-8">
                        <b><?php echo e($pengembalian_buku['tanggal_pinjam']); ?></b>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-4 col-form-label">Batas Waktu Pengembalian:</label>
                    <div class="col-sm-8">
                        <b><?php echo e($pengembalian_buku['tanggal_di_kembalikan']); ?></b>
                    </div>
                  </div> 
                  <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-4 col-form-label">Waktu Pengembalian:</label>
                    <div class="col-sm-8">
                        <b><?php echo e(\Carbon\Carbon::parse($pengembalian_buku['created_at'])->format('Y-m-d')); ?></b>
                    </div>
                  </div>  
                  <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-4 col-form-label">Total denda:</label>
                    <div class="col-sm-8">
                        <b>Rp. <?php echo e(number_format($denda, 0, ',', '.')); ?></b>
                    </div>
                  </div>                 
                  <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-4 col-form-label">Telah Di Bayar:</label>
                    <div class="col-sm-8">
                        <b>Rp. <?php echo e(number_format($pengembalian_buku['jumlah_denda'], 0, ',', '.')); ?></b>
                    </div>
                  </div> 
                  <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-4 col-form-label">Sisa Denda Yang Harus Di Bayar:</label>
                    <div class="col-sm-8">
                        
                        <b>Rp. <?php echo e(number_format($denda - $pengembalian_buku['jumlah_denda'], 0, ',', '.')); ?></b>

                    </div>
                  </div> 
                  <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-4 col-form-label">Status:</label>
                    <div class="col-sm-8">
                      <?php if($pengembalian_buku['jumlah_denda'] < $denda): ?>
                          <b><span class="btn btn-danger">Belum Lunas</span></b>
                      <?php else: ?>
                          <b><span class="btn btn-success">Lunas</span></b>
                      <?php endif; ?>
                    </div>
                  </div> 
                  <?php if($pengembalian_buku['jumlah_denda'] < $denda): ?>
                    <div class="row mb-3">
                      <label for="inputPassword3" class="col-sm-4 col-form-label">Bayar Sekarang:</label>
                      <div class="col-sm-8">
                          <b><a href="<?php echo e(url('admin/pengembalian_buku/bayar_denda/'. $pengembalian_buku['id'] )); ?>" class="btn btn-success"><i class="bi bi-arrow-bar-down" style="margin-right: 5px"></i>Klik Di Sini</a></b>
                      </div>
                    </div> 
                  <?php endif; ?>
                  <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-4 col-form-label"><a href="<?php echo e(url('admin/pengembalian_buku')); ?>" class="btn btn-primary">Kembali</a></label>        
                  </div> 

                </div>
            

              </div>
            </div>
          </div>
      </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Daftar Projek\perpustakaan-laravel-ajax\resources\views/admin/pengembalian_buku/show.blade.php ENDPATH**/ ?>