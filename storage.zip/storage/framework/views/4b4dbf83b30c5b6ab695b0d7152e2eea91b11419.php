
<!DOCTYPE html>
<html>
<head>
  <title>Tabel Cetak Denda Buku</title>
  <style>
    h3{
      margin-left:69px;
      margin-top: 30px;

    }

    table {
      border-collapse: collapse;
      width: 90%;
      margin: 0 auto;
    }
    
    th, td {
      padding: 8px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }
    
    th {
      background-color: #f2f2f2;
    }
  </style>
</head>
<body>
    <h3>Daftar Data Denda Buku</h3>
    <table class="table table-borderless datatable">
        <thead>
          <tr>
            <th scope="col">No</th>
            <th scope="col">Buku</th>
            <th scope="col">Murid</th>          
            <th scope="col">Jumlah Pinjam</th>             
            <th scope="col">Tanggal Pengembalian</th>             
            <th scope="col">Denda Di Bayar</th>             
            <th scope="col">Jumlah Denda</th>             
            
          </tr>
        </thead>
        <tbody>                      
          <?php
            use Carbon\Carbon;
          ?>
          <?php $__currentLoopData = $denda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
          
            <?php
                $denda_per_hari = 1000;                  
                $carbon_tanggal_hari_ini = \Carbon\Carbon::now()->setTimezone('Asia/Jakarta')->format('Y-m-d');


                $tanggal_kembali = Carbon::parse($value['tanggal_di_kembalikan']); 
                $created_at = Carbon::parse($value['created_at']); 

                $tanggal_hari_ini =  Carbon::parse($carbon_tanggal_hari_ini);

                if ($tanggal_kembali < $tanggal_hari_ini) {
                  $selisih_hari = $tanggal_hari_ini->diffInDays($tanggal_kembali);
                  $denda = $selisih_hari * $denda_per_hari;                      
                } else {
                  $denda = 0; 
                }

                $cek_selisih = $tanggal_kembali->diffInDays($created_at);

                $notifikasi_pembayaran = $denda - $value['jumlah_denda'];
            ?>       

            
              <tr>
                  <td><?php echo e($loop->iteration); ?></td>     
                  <td><?php echo e($value['buku']['judul']); ?></td>
                  <td><?php echo e($value['murid']['nama']); ?></td>
                  <td><?php echo e($value['jumlah_pinjam']); ?></td>    
                  <td>
                    <?php echo e(\Carbon\Carbon::parse($value['created_at'])->format('Y-m-d')); ?>

                    <br>
                    <span style="color:rgb(180, 15, 15);font-weight:bold">
                      Terlambat : <?php echo e($cek_selisih); ?> Hari
                    </span> 
                  </td>

                  <td>
                    Rp. <?php echo e(number_format($value['jumlah_denda'], 0, ',', '.')); ?>

                    <br>
                    <?php if($value['jumlah_denda'] == $denda): ?>
                      <span class="btn btn-sm btn-success">Lunas</span>
                    <?php else: ?>
                      <span class="btn btn-sm btn-danger">Belum Lunas</span>

                    <?php endif; ?>
                  </td>

                  <td>
                    Rp. <?php echo e(number_format($denda, 0, ',', '.')); ?>

                  </td>
                                                        
                  
                 
              </tr>  
            
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
      </table>
  <script>
      window.print();
  </script>

</body>
</html><?php /**PATH D:\Daftar Projek\perpustakaan-laravel-ajax\resources\views/admin/laporan/cetak_denda.blade.php ENDPATH**/ ?>