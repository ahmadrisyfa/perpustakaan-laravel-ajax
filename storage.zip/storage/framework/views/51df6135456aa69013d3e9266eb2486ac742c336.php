
<?php $__env->startSection('css_admin'); ?>
<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content_admin'); ?>
<style>
    .badge{cursor: pointer;}    
    .dataTable-input{        
        border: 1px solid black;
    }        
    @media only screen and (max-width: 520px) {
        .dataTable-dropdown  {
          display: none;
        }
    }
</style>        
    
    <div id="DetailListSiswa"></div>                 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Daftar Projek\perpustakaan-laravel-ajax\resources\views/siswa/detail.blade.php ENDPATH**/ ?>