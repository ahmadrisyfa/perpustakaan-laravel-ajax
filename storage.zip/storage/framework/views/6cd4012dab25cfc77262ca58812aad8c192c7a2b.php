
<!DOCTYPE html>
<html>
<head>
  <title>Tabel Cetak Pengembalian Buku</title>
  <style>
    h3{
      margin-left:69px;
      margin-top: 30px;

    }

    table {
      border-collapse: collapse;
      width: 90%;
      margin: 0 auto;
    }
    
    th, td {
      padding: 8px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }
    
    th {
      background-color: #f2f2f2;
    }
  </style>
</head>
<body>
    <h3>Daftar Data Pengembalian Buku</h3>
    <table>
        <thead>
          <tr>
            <th scope="col">No</th>
            <th scope="col">Buku</th>
            <th scope="col">Murid</th>          
            <th scope="col">Jumlah Pinjam</th>             
            <th scope="col">Tanggal Pinjam</th>             
            <th scope="col">Batas Di Kembalikan</th>             
            <th scope="col">Tanggal Pengembalian</th>             
            <th scope="col">Status</th>             
            
          </tr>
        </thead>
        <tbody>
          <?php
            use Carbon\Carbon;
          ?>
          <?php $__currentLoopData = $pengembalian_buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                
          <tr>
              <th><?php echo e($loop->iteration); ?></th>     
              <td><?php echo e($value['buku']['judul']); ?></td>
              <td><?php echo e($value['murid']['nama']); ?></td>
              <td><?php echo e($value['jumlah_pinjam']); ?></td>                
              <td><?php echo e($value['tanggal_pinjam']); ?></td>                
              <td><?php echo e($value['tanggal_di_kembalikan']); ?></td>  
              <td style="color:orange"><?php echo e(\Carbon\Carbon::parse($value['created_at'])->format('Y-m-d')); ?></td>
            
          <?php
              $denda_per_hari = 1000;                  
              $carbon_tanggal_hari_ini = \Carbon\Carbon::now()->setTimezone('Asia/Jakarta')->format('Y-m-d');


              $tanggal_kembali = Carbon::parse($value['tanggal_di_kembalikan']); 
              $tanggal_hari_ini =  Carbon::parse($carbon_tanggal_hari_ini);

              if ($tanggal_kembali < $tanggal_hari_ini) {
                $selisih_hari = $tanggal_hari_ini->diffInDays($tanggal_kembali);
                $denda = $selisih_hari * $denda_per_hari;                      
              } else {
                $denda = 0; 
              }
          ?>

                  
                <td>
                  <?php if($value['jumlah_denda'] < $denda): ?>
                    <button class="btn btn-danger btn-sm">Menunggak</button>                                          
                  <?php else: ?>
                    <button class="btn btn-success btn-sm">Selesai</button>
                  <?php endif; ?>
                </td>
              
          </tr> 

        
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
      </table>

  <script>
      window.print();
  </script>

</body>
</html><?php /**PATH D:\Daftar Projek\perpustakaan-laravel-ajax\resources\views/admin/laporan/cetak_pengembalian_buku.blade.php ENDPATH**/ ?>