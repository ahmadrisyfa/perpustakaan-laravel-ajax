
<?php $__env->startSection('content_admin'); ?>

<div class="pagetitle">
    <h1>Peminjaman</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#">Detail Peminjaman</a></li>
        
      </ol>
    </nav>
  </div><!-- End Page Title -->
  <section class="section">
      <div class="col-lg-12">
    <div class="row">

      <div class="col-lg-6">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Data Murid</h5>            
            <div>
              <div class="row mb-3">
                <label for="inputEmail3" class="col-sm-4 col-form-label">Nama:</label>
                <div class="col-sm-8">                
                  <b><?php echo e($pinjam_buku['murid']['nama']); ?></b>
                </div>
              </div>
              <div class="row mb-3">
                <label for="inputEmail3" class="col-sm-4 col-form-label">No Telepon:</label>
                <div class="col-sm-8">
                    <b><?php echo e($pinjam_buku['murid']['no_telepon']); ?></b>
                </div>
              </div>
              <div class="row mb-3">
                <label for="inputPassword3" class="col-sm-4 col-form-label">Alamat:</label>
                <div class="col-sm-8">
                    <b><?php echo e($pinjam_buku['murid']['alamat']); ?></b>
                </div>
              </div> 
              <div class="row mb-3">
                <label for="inputPassword3" class="col-sm-4 col-form-label">Tanggal Lahir:</label>
                <div class="col-sm-8">
                    <b><?php echo e($pinjam_buku['murid']['tanggal_lahir']); ?></b>
                </div>
              </div> 
              <div class="row mb-3">
                <label for="inputPassword3" class="col-sm-4 col-form-label">Jenis Kelamin:</label>
                <div class="col-sm-8">
                    <b><?php echo e($pinjam_buku['murid']['jenis_kelamin']); ?></b>
                </div>
              </div>                                         
            </div>

          </div>
        </div>    
      </div>

      <div class="col-lg-6">

        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Data Buku</h5>

            <div>
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-4 col-form-label">Judul:</label>
                  <div class="col-sm-8">                
                    <b><?php echo e($pinjam_buku['buku']['judul']); ?></b>
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-4 col-form-label">Pengarang:</label>
                  <div class="col-sm-8">
                      <b><?php echo e($pinjam_buku['buku']['pengarang']); ?></b>
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputPassword3" class="col-sm-4 col-form-label">Penerbit:</label>
                  <div class="col-sm-8">
                      <b><?php echo e($pinjam_buku['buku']['penerbit']); ?></b>
                  </div>
                </div> 
                <div class="row mb-3">
                  <label for="inputPassword3" class="col-sm-4 col-form-label">Isbn:</label>
                  <div class="col-sm-8">
                      <b><?php echo e($pinjam_buku['buku']['isbn']); ?></b>
                  </div>
                </div> 
                <div class="row mb-3">
                  <label for="inputPassword3" class="col-sm-4 col-form-label">Tahun:</label>
                  <div class="col-sm-8">
                      <b><?php echo e($pinjam_buku['buku']['tahun']); ?></b>
                  </div>
                </div> 
                <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-4 col-form-label">Sampul Buku:</label>
                    <div class="col-sm-8">
                        <b><img src="<?php echo e(asset('storage/'.$pinjam_buku['buku']['sampul_buku'] )); ?>" class="w-100" alt="sampul buku" alt=""></b>
                    </div>
                  </div>                                         
              </div>

          </div>
        </div>



      </div>
    </div>      
    </div>

    <div class="col-lg-12">
        <div class="row">
    
          <div class="col-lg-12">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title">Data Pinjam Buku</h5>            
                <div>
                  <div class="row mb-3">
                    <label for="inputEmail3" class="col-sm-4 col-form-label">Jumlah Pinjam:</label>
                    <div class="col-sm-8">                
                      <b><?php echo e($pinjam_buku['jumlah_pinjam']); ?></b>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <label for="inputEmail3" class="col-sm-4 col-form-label">Tanggal Pinjam:</label>
                    <div class="col-sm-8">
                        <b><?php echo e($pinjam_buku['tanggal_pinjam']); ?></b>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-4 col-form-label">Tanggal Di Kembalikan:</label>
                    <div class="col-sm-8">
                        <b><?php echo e($pinjam_buku['tanggal_di_kembalikan']); ?></b>
                    </div>
                  </div> 
                  
                </div>

                <div>
                  <div class="row mb-3">
                    <label for="inputEmail3" class="col-sm-4 col-form-label">
                    

                      <form action="<?php echo e(url('admin/pengembalian_buku/create')); ?>" onsubmit="return confirm('Yakin Ingin Mengembalikan Buku Ini?')"   method="post">
                        <?php echo csrf_field(); ?>
                        
                        
                        <input type="hidden" name="id_pinjam_buku" value="<?php echo e($pinjam_buku['id']); ?>" >


                        <input type="hidden" name="buku_id" value="<?php echo e($pinjam_buku['buku_id']); ?>" >
                        <input type="hidden" name="murid_id" value="<?php echo e($pinjam_buku['murid_id']); ?>" >
                        <input type="hidden" name="jumlah_pinjam" value="<?php echo e($pinjam_buku['jumlah_pinjam']); ?>" >
                        <input type="hidden" name="tanggal_pinjam" value="<?php echo e($pinjam_buku['tanggal_pinjam']); ?>" >
                        <input type="hidden" name="tanggal_di_kembalikan" value="<?php echo e($pinjam_buku['tanggal_di_kembalikan']); ?>" >
                        <input type="hidden" name="jumlah_denda" value="0" >
                        <input type="hidden" name="status" value="<?php echo e($pinjam_buku['status']); ?>" >

                        <b>
                          <button class="btn btn-primary"><i class="bi bi-arrow-90deg-left" style="margin-right: 5px"></i>Pengembalian Buku</button>
                        </b>
                      </form>
                    </label>
                    <div class="col-sm-4">                
                    <b>
                      <form action="<?php echo e(url('admin/pinjam_buku/delete/'.$pinjam_buku['id'])); ?>" method="POST" onsubmit="return confirm('Apakah Anda Yakin Ingin Menghapus Data Ini?')" class="d-inline">
                        <?php echo csrf_field(); ?>                                      
                        <?php echo method_field('delete'); ?>
                        <button type="submit" class="btn btn-danger"><i class="bi bi-trash" style="margin-right: 5px"></i>Hapus</button>
                      </form>
                    </b>
                    </div>
                    <div class="col-sm-4">                
                      <b>
                        <a href="<?php echo e(url('admin/pinjam_buku')); ?>" class="btn btn-info"><i class="bi bi-arrow-bar-right" style="margin-right: 5px"></i>kembali</a>
                      </b>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Daftar Projek\perpustakaan-laravel-ajax\resources\views/admin/pinjam_buku/show.blade.php ENDPATH**/ ?>