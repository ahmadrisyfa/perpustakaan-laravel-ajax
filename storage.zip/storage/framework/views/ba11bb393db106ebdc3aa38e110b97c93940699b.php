
<!DOCTYPE html>
<html>
<head>
  <title>Tabel Cetak</title>
  <style>
    h3{
      margin-left:69px;
      margin-top: 30px;

    }

    table {
      border-collapse: collapse;
      width: 90%;
      margin: 0 auto;
    }
    
    th, td {
      padding: 8px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }
    
    th {
      background-color: #f2f2f2;
    }
  </style>
</head>
<body>
    <h3>Daftar Data Pinjam Buku</h3>
    <table>
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Buku</th>
                <th scope="col">Murid</th>          
                <th scope="col">Jumlah Pinjam</th>             
                <th scope="col">Tanggal Pinjam</th>             
                <th scope="col">Batas Di Kembalikan</th>             
                <th scope="col">Denda</th>             
                <th scope="col">Status</th>             
              </tr>
        </thead>
        <tbody>
            <?php
            use Carbon\Carbon;
            ?>
            <?php $__currentLoopData = $pinjam_buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                
            <tr>
                <td><?php echo e($loop->iteration); ?></td>     
                <td><?php echo e($value['buku']['judul']); ?></td>
                <td><?php echo e($value['murid']['nama']); ?></td>
                <td><?php echo e($value['jumlah_pinjam']); ?></td>                
                <td><?php echo e($value['tanggal_pinjam']); ?></td>                
                <td><?php echo e($value['tanggal_di_kembalikan']); ?></td>  

                <?php
                    $denda_per_hari = 1000;                  
                    $carbon_tanggal_hari_ini = \Carbon\Carbon::now()->setTimezone('Asia/Jakarta')->format('Y-m-d');


                    $tanggal_kembali = Carbon::parse($value['tanggal_di_kembalikan']); 
                    $tanggal_hari_ini =  Carbon::parse($carbon_tanggal_hari_ini);

                    if ($tanggal_kembali < $tanggal_hari_ini) {
                      $selisih_hari = $tanggal_hari_ini->diffInDays($tanggal_kembali);
                      $denda = $selisih_hari * $denda_per_hari;                      
                    } else {
                      $denda = 0; 
                    }
                ?> 
                   
                  <?php if($denda <= 0): ?>                      
                    <td><p>Tidak Ada Denda Yang Harus Di Bayar</p></td>          
                  <?php else: ?>
                    <?php if($denda > 0): ?>
                      <td>Rp. <?php echo e(number_format($denda, 0, ',', '.')); ?></td>  
                    <?php else: ?>    
                      <td><p>Tidak Ada Denda Yang Harus Di Bayar</p></td>          
                    <?php endif; ?>
                  <?php endif; ?>
                  <td>
                    <?php if($denda > 0): ?>
                      <button class="btn btn-danger btn-sm">Terlambat</button>                                          
                    <?php else: ?>
                      <button class="btn btn-success btn-sm">Normal</button>
                    <?php endif; ?>
                  </td>
            </tr> 

          
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </tbody>
      </table>

  <script>
      window.print();
  </script>

</body>
</html><?php /**PATH D:\Daftar Projek\perpustakaan-laravel-ajax\resources\views/admin/laporan/cetak_pinjam_buku.blade.php ENDPATH**/ ?>