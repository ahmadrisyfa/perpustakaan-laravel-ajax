
<?php $__env->startSection('content_admin'); ?>
<style>
    .badge{cursor: pointer;}    
    .dataTable-input{        
        border: 1px solid black;
    }        
    @media only screen and (max-width: 520px) {
        .dataTable-dropdown  {
          display: none;
        }
    }
</style>

<div class="col-12">
    <div class="card recent-sales overflow-auto">
      <div class="card-body">
        <h5 class="card-title">Data Pinjam Buku <span>| Tambahkan Data</span></h5>
        <?php if($errors->any()): ?>
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                  
              <li><?php echo e($item); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>

        <?php if(session()->has('success')): ?>
        <div class="alert alert-success">
          <?php echo e(session('success')); ?>

        </div>
            
        <?php endif; ?>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#createModal">
          Tambah Data</button>
        <table class="table table-borderless datatable">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Buku</th>
              <th scope="col">Murid</th>          
              <th scope="col">Jumlah Pinjam</th>             
              <th scope="col">Tanggal Pinjam</th>             
              <th scope="col">Batas Di Kembalikan</th>             
              <th scope="col">Denda</th>             
              <th scope="col">Status</th>             
              <th scope="col">Action</th>             
            </tr>
          </thead>
          <tbody>
            <?php
            use Carbon\Carbon;
            ?>
            <?php $__currentLoopData = $pinjam_buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                
            <tr>
                <th scope="row"><?php echo e($loop->iteration); ?></th>     
                <td><?php echo e($value['buku']['judul']); ?></td>
                <td><?php echo e($value['murid']['nama']); ?></td>
                <td><?php echo e($value['jumlah_pinjam']); ?></td>                
                <td><?php echo e($value['tanggal_pinjam']); ?></td>                
                <td><?php echo e($value['tanggal_di_kembalikan']); ?></td>  

                <?php
                    $denda_per_hari = 1000;                  
                    $carbon_tanggal_hari_ini = \Carbon\Carbon::now()->setTimezone('Asia/Jakarta')->format('Y-m-d');


                    $tanggal_kembali = Carbon::parse($value['tanggal_di_kembalikan']); 
                    $tanggal_hari_ini =  Carbon::parse($carbon_tanggal_hari_ini);

                    if ($tanggal_kembali < $tanggal_hari_ini) {
                      $selisih_hari = $tanggal_hari_ini->diffInDays($tanggal_kembali);
                      $denda = $selisih_hari * $denda_per_hari;                      
                    } else {
                      $denda = 0; 
                    }
                ?> 
                   
                  <?php if($denda <= 0): ?>                      
                    <td><p>Tidak Ada Denda Yang Harus Di Bayar</p></td>          
                  <?php else: ?>
                    <?php if($denda > 0): ?>
                      <td>Rp. <?php echo e(number_format($denda, 0, ',', '.')); ?></td>  
                    <?php else: ?>    
                      <td><p>Tidak Ada Denda Yang Harus Di Bayar</p></td>          
                    <?php endif; ?>
                  <?php endif; ?>
                  <td>
                    <?php if($denda > 0): ?>
                      <button class="btn btn-danger btn-sm">Terlambat</button>                                          
                    <?php else: ?>
                      <button class="btn btn-success btn-sm">Normal</button>
                    <?php endif; ?>
                  </td>
                  <td>
                    
                    <a href="<?php echo e(url('admin/pinjam_buku/show/'.$value['id'])); ?>" class="btn btn-info btn-sm"><i class="bi bi-eye"></i>Detail</a>
                    
                </td>
            </tr> 

            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </tbody>
        </table>

      </div>

    </div>
  </div>


  
  <div class="modal fade" id="createModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Tambah Data Pinjam Buku</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form action="<?php echo e(url('admin/pinjam_buku/create')); ?>"  method="post">
            <?php echo csrf_field(); ?>
            <div class="col-12">
              <label for="yourUsername" class="form-label">Buku</label>
              <div class="input-group has-validation">
                <select name="buku_id" id="buku_id" required class="form-select">
                  <option value="" selected disabled style="text-align:center">-- Silahkan Pilih Daftar Buku --</option>
                  <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daftar_buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($daftar_buku->id); ?>"><?php echo e($daftar_buku->judul); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>   
            <div class="col-12">
              <label for="yourUsername" class="form-label">Murid</label>
              <div class="input-group has-validation">
                <select name="murid_id" id="murid_id" required class="form-select">
                  <option value="" selected disabled style="text-align:center">-- Silahkan Pilih Daftar Murid --</option>
                  <?php $__currentLoopData = $murid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daftar_murid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($daftar_murid->id); ?>"><?php echo e($daftar_murid->nama); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>                                                                                                                                   
                <div class="col-12">
                  <label for="yourUsername" class="form-label">Jumlah Pinjam</label>
                  <div class="input-group has-validation">
                    <input type="number" class="form-control" name="jumlah_pinjam" required>
                  </div>
                </div>
                <div class="col-12">
                  <label for="yourUsername" class="form-label">Tanggal Pinjam</label>
                  <div class="input-group has-validation">
                    <input type="date" class="form-control" name="tanggal_pinjam" required onchange="setReturnDate()">
                  </div>
                </div> 
                
                    <input type="hidden" class="form-control" name="tanggal_di_kembalikan" required>
                  
                
                    <input type="hidden" readonly class="form-control" name="jumlah_denda" value="0" required>
                    <input type="hidden" readonly class="form-control" name="status" value="0" required>

               
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  
  <script>
    function setReturnDate() {
        let tanggalPinjam = document.querySelector('input[name="tanggal_pinjam"]').value;
        if (tanggalPinjam) {
            let tanggalPinjamDate = new Date(tanggalPinjam);
            tanggalPinjamDate.setDate(tanggalPinjamDate.getDate() + 7);
            let year = tanggalPinjamDate.getFullYear();
            let month = (tanggalPinjamDate.getMonth() + 1).toString().padStart(2, '0');
            let day = tanggalPinjamDate.getDate().toString().padStart(2, '0');
            document.querySelector('input[name="tanggal_di_kembalikan"]').value = `${year}-${month}-${day}`;
        }
    }
  </script>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Daftar Projek\perpustakaan-laravel-ajax\resources\views/admin/pinjam_buku/index.blade.php ENDPATH**/ ?>