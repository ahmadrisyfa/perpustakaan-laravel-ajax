<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Perpustakaan | Daftar Buku</title>
    <script type="text/javascript"> (function() { var css = document.createElement('link'); css.href = 'https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'; css.rel = 'stylesheet'; css.type = 'text/css'; document.getElementsByTagName('head')[0].appendChild(css); })(); </script>
    <link rel="stylesheet" href="<?php echo e(asset('template-pinterest')); ?>/docs/assets/css/app.css">
    <link rel="stylesheet" href="<?php echo e(asset('template-pinterest')); ?>/docs/assets/css/theme.css">
    <link rel="shortcut icon" href="<?php echo e(asset('template-pinterest')); ?>/docs/assets/img/logo.png" type="image/x-icon">
</head>

<body>
	<nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top">
				<a class="navbar-brand font-weight-bolder mr-3" href="<?php echo e(url('daftar_buku')); ?>"><img src="<?php echo e(asset('template-pinterest')); ?>/docs/assets/img/logo.png"></a>
				<button class="navbar-light navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsDefault" aria-controls="navbarsDefault" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
		<div class="collapse navbar-collapse" id="navbarsDefault">
					<ul class="navbar-nav mr-auto align-items-center">
						<h3>
							<a href="<?php echo e(url('daftar_buku')); ?>">
									Perpustakaan
							</a>
						</h3>
					</ul>
			<ul class="navbar-nav ml-auto align-items-center">
				<li class="nav-item">
				<a class="nav-link active" href="<?php echo e(url('daftar_buku')); ?>">Daftar Buku</a>
				</li>
				<?php if(auth()->guard()->check()): ?>
					<li class="nav-item">
						<a class="nav-link" href="#"><?php echo e(auth()->user()->name); ?></a>
					</li>
				<?php else: ?>		
					<li class="nav-item">
						<a class="nav-link" href="<?php echo e(url('/login')); ?>">Login</a>
					</li>
				<?php endif; ?>
			</ul>
		</div>
    </nav>    
    <main role="main">        
    <section class="mt-4 mb-5">
    <div class="container mb-4">
    	<h1 class="font-weight-bold title">Daftar Buku</h1>
    	<div class="row">
    		<nav class="navbar navbar-expand-lg navbar-light bg-white pl-2 pr-2">
				<button class="navbar-light navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExplore" aria-controls="navbarsDefault" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbarsExplore">
					<ul class="navbar-nav">
						<li class="nav-item">    				
							<form action="<?php echo e(url('daftar_buku/search')); ?>" method="GET">
							<div class="input-group mb-3">
									<input name="search" value="<?php echo e(request('search')); ?>" type="text" class="mt-4 form-control bg-graylight border-0 font-weight-bold" id="search-input" placeholder="Search Judul / Pengarang" autocomplete="off">
									<div class="input-group-append">
									<button class="btn btn-outline-danger mt-4" type="button">Cari</button>
									</div>
								</div>	
							</form>
						</li>    				
					</ul>
				</div>
    		</nav>
    	</div>
    </div>
    <div class="container-fluid">
		<?php if($buku->isEmpty()): ?>
			<h5 class="text-center">
				-- Tidak Ada Data Buku <?php echo e(request('search')); ?> --
			</h5>
		<?php else: ?>
			<div class="row">
				<div class="card-columns">
					<?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>					
						<div class="card card-pin">
							<img class="card-img" src="<?php echo e(asset('storage/'.$value->sampul_buku)); ?>">
							<div class="overlay">
								<h2 class="card-title title"><?php echo e($value->judul); ?></h2>
								<div class="more">
									<a href="post.html">
										<i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i> Detail Lengkap....</a>
								</div>
							</div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
				</div>
			</div>
		<?php endif; ?>
    </div>
    </section>
        
    </main>

    <script src="<?php echo e(asset('template-pinterest')); ?>/docs/assets/js/app.js"></script>
    <script src="<?php echo e(asset('template-pinterest')); ?>/docs/assets/js/theme.js"></script>
    
       
</body>
    
</html>
<?php /**PATH D:\Daftar Projek\perpustakaan-laravel-ajax\resources\views/daftar_buku.blade.php ENDPATH**/ ?>